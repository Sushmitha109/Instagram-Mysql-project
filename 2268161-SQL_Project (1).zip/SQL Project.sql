-- How many times does the average user post?
SELECT AVG(post_count) AS average_posts
FROM (SELECT u.id AS user_id, COUNT(p.id) AS post_count
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id
    GROUP BY u.id) AS user_post_counts;

-- Find the top 5 most used hashtags.
Select tags.id, tags.tag_name, COUNT(*) AS total 
FROM tags INNER JOIN photo_tags ON tags.id = photo_tags.tag_id
GROUP BY tags.id
ORDER BY total DESC
LIMIT 5;

-- Find users who have liked every single photo on the site.
SELECT users.id,username, COUNT(users.id) As total_likes_by_user
FROM users
JOIN likes ON users.id = likes.user_id
GROUP BY users.id
HAVING total_likes_by_user = (SELECT COUNT(*) FROM photos);

-- Retrieve a list of users along with their usernames and the rank of their account creation, ordered by the creation date in ascending order.
SELECT id, username, created_at, DENSE_RANK() OVER (ORDER BY created_at ASC) AS account_creation_rank
FROM users
ORDER BY created_at ASC;

-- List the comments made on photos with their comment texts, photo URLs, and usernames of users who posted the comments. Include the comment count for each photo
SELECT
    c.comment_text,
    p.image_url AS photo_url,
    u.username AS user_username,
    p.user_id AS photo_user_id,
    COUNT(*) AS comment_count
FROM comments c
INNER JOIN photos p ON c.photo_id = p.id
INNER JOIN users u ON c.user_id = u.id
GROUP BY c.comment_text, p.image_url, u.username, p.user_id;

-- For each tag, show the tag name and the number of photos associated with that tag. Rank the tags by the number of photos in descending order.
SELECT t.tag_name,COUNT(pt.photo_id) AS photo_count
FROM tags t
LEFT JOIN photo_tags pt ON t.id = pt.tag_id
GROUP BY t.tag_name
ORDER BY photo_count DESC;

-- List the usernames of users who have posted photos along with the count of photos they have posted. Rank them by the number of photos in descending order.
SELECT u.username, COUNT(p.id) AS photo_count
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
GROUP BY u.username
ORDER BY photo_count DESC;

-- Display the username of each user along with the creation date of their first posted photo and the creation date of their next posted photo.

SELECT username, first_photo_created_at, next_photo_created_at
FROM ( SELECT
        u.username,
        p.created_at AS first_photo_created_at,
        LEAD(p.created_at) OVER (PARTITION BY p.user_id ORDER BY p.created_at) AS next_photo_created_at,
        ROW_NUMBER() OVER (PARTITION BY p.user_id ORDER BY p.created_at) AS rn
FROM users u LEFT JOIN photos p ON u.id = p.user_id) AS UserFirstNextPhotos
WHERE rn = 1;

-- For each comment, show the comment text, the username of the commenter, and the comment text of the previous comment made on the same photo.
 SELECT c.comment_text, u.username AS commenter_username, p.id AS photo_id,
LAG(c.comment_text) OVER (PARTITION BY p.id ORDER BY c.created_at) AS previous_comment_text
FROM comments c
INNER JOIN users u ON c.user_id = u.id
INNER JOIN photos p ON c.photo_id = p.id;

-- Show the username of each user along with the number of photos they have posted and the number of photos posted by the user before them and after them, based on the creation date
SELECT username, created_at, photos_before, photos_after
FROM (
      SELECT u.username, p.created_at,
        COUNT(p.id) OVER (PARTITION BY u.id ORDER BY p.created_at) AS photos_before,
        COUNT(p.id) OVER (PARTITION BY u.id ORDER BY p.created_at DESC) AS photos_after
    FROM users u
    LEFT JOIN photos p ON u.id = p.user_id) AS UserPhotoCounts
ORDER BY created_at;



 
 
 
 